# App store assets

Drop two PNGs in this folder, then run `npm run cap:icons` to generate every
size iOS and Android need.

## Required files

| File | Min size | Notes |
|------|----------|-------|
| `icon.png` | **1024 × 1024** | Square, no transparency, no rounded corners (the OS rounds them). The thing you'd recognise as the app icon on a home screen. |
| `splash.png` | **2732 × 2732** | Centered logo on a solid background. The OS crops this for every device aspect ratio, so put nothing important within ~25% of the edges. |

Optional:

| File | Notes |
|------|-------|
| `icon-foreground.png` | 1024 × 1024 transparent foreground (Android adaptive icon). |
| `icon-background.png` | 1024 × 1024 solid-colour background (Android adaptive icon). |
| `splash-dark.png` | 2732 × 2732 dark-mode splash. |

## After adding the files

```bash
npm run cap:icons          # writes every required size into ios/ and android/
npm run cap:sync           # rebuilds web + copies into native projects
npm run cap:open:ios       # opens Xcode (macOS only)
npm run cap:open:android   # opens Android Studio
```
