import './style.css';
import heroImg from './assets/hero.png';
import { CipherEngines } from './ciphers/all-engines.js';

export const cipherNames = Object.keys(CipherEngines);

const LABEL_OVERRIDES = {
  vigenere: 'Vigenère',
  confederateVigenere: 'Confederate Vigenère',
  adfgx: 'ADFGX',
  adfgvx: 'ADFGVX',
  otp: 'One-Time Pad',
  vic: 'VIC',
  rot13: 'ROT13',
  foursquare: 'Four-Square',
  twosquare: 'Two-Square',
  m209: 'M-209',
  m94: 'M-94',
  kl7: 'KL-7',
  jn25: 'JN-25',
  redTypeA: 'Red (Type A)',
  sigaba: 'SIGABA',
  arnoldAndre: 'Arnold–André',
  geezMonastic: "Ge'ez Monastic",
  joseonYeokhak: 'Joseon Yeokhak',
  jefferson: 'Jefferson Disk',
  kamaSutra: 'Kama Sutra',
};

export function humanLabel(name) {
  if (LABEL_OVERRIDES[name]) return LABEL_OVERRIDES[name];
  return name
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/^./, c => c.toUpperCase());
}

function normalizeName(s) {
  return String(s)
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]/g, '');
}

// Stable global mapping: every cipher gets a fixed letter code based on its
// position in the registry (A, B, …, Z, AA, AB, … CF for 84 ciphers).
// The mapping is the same across all installs of this app version, so the
// legend the recipient pastes only needs to carry the codes — no cipher
// names — which sidesteps clipboard mangling (URL-encoding of accents,
// spaces becoming %20, autocorrect rewriting names, etc.).
function buildGlobalCodeMap() {
  const codeByName = {};
  const nameByCode = {};
  cipherNames.forEach((name, i) => {
    const code = codeForIndex(i);
    codeByName[name] = code;
    nameByCode[code] = name;
  });
  return { codeByName, nameByCode };
}
const { codeByName: GLOBAL_CODE_BY_CIPHER, nameByCode: GLOBAL_CIPHER_BY_CODE } =
  buildGlobalCodeMap();

export function codeForCipher(name) {
  return GLOBAL_CODE_BY_CIPHER[name] || null;
}
export function cipherForCode(code) {
  return GLOBAL_CIPHER_BY_CODE[String(code).toUpperCase()] || null;
}

const NAME_LOOKUP = (() => {
  const m = {};
  for (const name of cipherNames) {
    m[normalizeName(name)] = name;
    m[normalizeName(humanLabel(name))] = name;
  }
  return m;
})();

export function resolveCipherName(input) {
  return NAME_LOOKUP[normalizeName(input)] || null;
}

export function pickCiphersForWords(wordCount) {
  const pool = cipherNames.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const out = [];
  for (let i = 0; i < wordCount; i++) {
    out.push(pool[i % pool.length]);
  }
  return out;
}

export function codeForIndex(i) {
  let s = '';
  let n = i;
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return s;
}

// Build a per-position legend: one entry per word, in word order, using
// the stable global cipher → code mapping (same for every install).
// Format: [{ code: 'A', cipher: 'caesar' }, { code: 'B', cipher: 'monoalphabetic' }, …]
export function buildLegend(ciphersForWords) {
  return ciphersForWords.map(cipher => ({
    code: GLOBAL_CODE_BY_CIPHER[cipher],
    cipher,
  }));
}

// Plain-text format the Copy legend button writes to the clipboard.
// Codes only — no cipher names — so the paste survives URL-encoding,
// autocorrect, and other clipboard mangling.
export function legendToText(legend) {
  return legend.map(({ code }) => code).join(', ');
}

// Parse the legend the recipient pasted. Tolerant of:
//
//   "A, B, C"                       ← canonical (codes only — current copy)
//   "A B C"                         ← whitespace-separated codes
//   "A%20B%20C" / "A%2C%20B"        ← URL-encoded paste from messaging apps
//   "A\nB\nC"                       ← one code per line
//   "AA, AB, BB"                    ← double-letter codes for cipher #27+
//   "A: Caesar, B: Vigenère"        ← legacy code+name format (still works)
//   "A: Caesar B: Vigenère"         ← whitespace-collapsed legacy
//   "Caesar\nVigenère"              ← bare positional names (still works)
//
// Returns an ordered array of resolved cipher names.
export function parseLegend(text) {
  if (!text) return [];
  let src = String(text);
  // Repair URL-encoded clipboard pastes (mobile + some messaging apps wrap
  // copied text in URL-encoding, turning ": " into "%3A%20").
  if (/%[0-9A-Fa-f]{2}/.test(src)) {
    try { src = decodeURIComponent(src); } catch { /* leave as-is */ }
  }

  // First try the legacy <CODE><sep><NAME> shape — if any entries match,
  // they take precedence (the name is more authoritative than a bare code,
  // since it survives even if the global map shifts).
  const named = [];
  const namedRe = /([A-Za-z]{1,3})\s*[:=\-–—|]\s*([^,;\n]+?)(?=(?:\s+[A-Za-z]{1,3}\s*[:=\-–—|])|\s*[,;\n]|\s*$)/g;
  let m;
  while ((m = namedRe.exec(src)) !== null) {
    const code = m[1].toUpperCase();
    const cipher = resolveCipherName(m[2]);
    if (cipher) named.push({ code, cipher });
  }
  if (named.length > 0) {
    if (named.length > 1 && named.every(e => e.code !== null)) {
      named.sort((a, b) => {
        if (a.code.length !== b.code.length) return a.code.length - b.code.length;
        return a.code.localeCompare(b.code);
      });
    }
    return named.map(e => e.cipher);
  }

  // Code-only path: walk the input left-to-right, pulling out every
  // 1-3 letter sequence. Order matters (each code maps to a token
  // position), so we don't sort.
  const codeOnly = [];
  const codeRe = /\b([A-Za-z]{1,3})\b/g;
  while ((m = codeRe.exec(src)) !== null) {
    const cipher = GLOBAL_CIPHER_BY_CODE[m[1].toUpperCase()];
    if (cipher) codeOnly.push(cipher);
  }
  if (codeOnly.length > 0) return codeOnly;

  // Last-resort fallback: bare cipher names, one per line / comma /
  // semicolon (e.g. "Caesar\nVigenère").
  const bare = [];
  for (const raw of src.split(/[\r\n,;]+/)) {
    const cipher = resolveCipherName(raw.trim());
    if (cipher) bare.push(cipher);
  }
  return bare;
}

// Decode tokens positionally: token N is decoded with legend[N]'s cipher.
export function decodeFromLegend(ciphertext, legend, key) {
  if (!ciphertext) return { text: '', missingPositions: [] };
  const tokens = String(ciphertext).split('|').map(t => t.trim()).filter(Boolean);
  const out = [];
  const missing = [];
  for (let i = 0; i < tokens.length; i++) {
    const tok = tokens[i];
    const cipher = legend[i];
    if (!cipher) {
      missing.push(i + 1);
      out.push(tok);
      continue;
    }
    try {
      const dec = CipherEngines[cipher].decode(tok, key || 'KEY');
      out.push(dec || tok);
    } catch {
      out.push(tok);
    }
  }
  return { text: out.join(' '), missingPositions: missing };
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[c]);
}

function render(root) {
  root.innerHTML = `
    <header class="hero">
      <img src="${heroImg}" alt="" width="64" height="64" class="hero-img" />
      <div class="hero-text">
        <h1 id="appTitle">Cipher Mix</h1>
        <p class="lede">Encrypt each word with a different cipher from a library of <strong>${cipherNames.length}</strong>. Share the ciphertext + legend; the recipient decodes it.</p>
      </div>
    </header>

    <div class="tabs" role="tablist" aria-label="Mode">
      <button role="tab" id="encryptTab" class="tab" aria-selected="true" aria-controls="encryptPanel" tabindex="0" type="button">Encrypt</button>
      <button role="tab" id="decryptTab" class="tab" aria-selected="false" aria-controls="decryptPanel" tabindex="-1" type="button">Decrypt</button>
    </div>

    <section id="encryptPanel" role="tabpanel" aria-labelledby="encryptTab" class="panel" tabindex="0">
      <details class="howto">
        <summary>How encryption works</summary>
        <ol>
          <li>Type a message. Each word is encoded with a different cipher.</li>
          <li>Click <strong>Encrypt</strong>. You get a <em>ciphertext</em> (tokens separated by <code>|</code>) and a <em>legend</em> — a short list of letter codes, one per word.</li>
          <li>Click <strong>Copy ciphertext</strong> and <strong>Copy legend</strong> — <strong>send both</strong> to your recipient. The on-screen legend shows the cipher names too, but only the letters get copied (so nothing gets mangled by clipboards / messaging apps).</li>
        </ol>
        <p class="howto-example">Example:<br>
          <strong>Ciphertext:</strong> <code>KHOOR | LSPPV</code><br>
          <strong>Legend (copied):</strong> <code>A, B</code>
        </p>
      </details>

      <label for="inputText" class="field-label">Your message</label>
      <textarea
        id="inputText"
        rows="3"
        autocomplete="off"
        autocapitalize="none"
        spellcheck="false"
        placeholder="Type a few words…"
        aria-describedby="inputHelp"
      ></textarea>
      <p id="inputHelp" class="hint"><kbd>Ctrl</kbd>+<kbd>Enter</kbd> to encrypt.</p>
      <div class="actions">
        <button id="encryptBtn" type="button" class="btn-primary">
          <span aria-hidden="true">🔒</span> Encrypt message
        </button>
        <button id="clearBtn" type="button" class="btn-secondary">Clear</button>
      </div>

      <div class="output-block step" data-step="1">
        <div class="output-head">
          <h2 id="outputHeading"><span class="step-num" aria-hidden="true">1</span> Ciphertext</h2>
          <button id="copyEncryptBtn" type="button" class="btn-ghost" aria-label="Copy ciphertext to clipboard" disabled>Copy ciphertext</button>
        </div>
        <div id="outputText" class="output" role="region" aria-live="polite" aria-atomic="true" aria-labelledby="outputHeading" data-state="empty"></div>
      </div>

      <div class="callout" role="note">
        <strong>Send both</strong> the ciphertext above <em>and</em> the legend below to your recipient. Both are needed to decrypt.
      </div>

      <div class="output-block step" data-step="2">
        <div class="output-head">
          <h2 id="legendHeading"><span class="step-num" aria-hidden="true">2</span> Cipher legend</h2>
          <button id="copyLegendBtn" type="button" class="btn-ghost" aria-label="Copy legend to clipboard" disabled>Copy legend</button>
        </div>
        <dl id="cipherLegend" class="legend" aria-labelledby="legendHeading"></dl>
      </div>
    </section>

    <section id="decryptPanel" role="tabpanel" aria-labelledby="decryptTab" class="panel" tabindex="0" hidden>
      <details class="howto">
        <summary>How decryption works</summary>
        <ol>
          <li>Paste the <strong>ciphertext</strong> you received into field 1. Tokens are separated by <code>|</code>.</li>
          <li>Paste the <strong>legend</strong> into field 2 — usually a short list of letter codes like <code>A, B, C</code>. URL-encoded, comma-separated, line-separated, all fine.</li>
          <li>Enter the <strong>key</strong> if one was used, then click <strong>Decrypt</strong>.</li>
        </ol>
        <p class="howto-example">Example:<br>
          <strong>Ciphertext:</strong> <code>KHOOR | LSPPV</code><br>
          <strong>Legend:</strong> <code>A, B</code>
        </p>
      </details>

      <label for="cipherText" class="field-label"><span class="step-num" aria-hidden="true">1</span> Ciphertext</label>
      <textarea
        id="cipherText"
        rows="3"
        autocomplete="off"
        autocapitalize="none"
        spellcheck="false"
        placeholder="KHOOR | OWWAR | …"
      ></textarea>

      <label for="legendInput" class="field-label"><span class="step-num" aria-hidden="true">2</span> Cipher legend</label>
      <textarea
        id="legendInput"
        rows="2"
        autocomplete="off"
        autocapitalize="none"
        spellcheck="false"
        placeholder="A, B, C"
        aria-describedby="legendHint"
      ></textarea>
      <p id="legendHint" class="hint">Just the letter codes from the encrypt screen, in any layout — commas, spaces, or newlines.</p>

      <label for="cipherKey" class="field-label"><span class="step-num" aria-hidden="true">3</span> Key (if required)</label>
      <input
        id="cipherKey"
        type="text"
        autocomplete="off"
        autocapitalize="none"
        spellcheck="false"
        placeholder="KEY"
      />

      <div class="actions">
        <button id="decryptBtn" type="button" class="btn-primary btn-decrypt">
          <span aria-hidden="true">🔓</span> Decrypt message
        </button>
        <button id="clearDecryptBtn" type="button" class="btn-secondary">Clear</button>
      </div>

      <div class="output-block">
        <div class="output-head">
          <h2 id="decryptedHeading">Decrypted message</h2>
          <button id="copyDecryptBtn" type="button" class="btn-ghost" aria-label="Copy decrypted message to clipboard" disabled>Copy</button>
        </div>
        <div id="decryptedText" class="output" role="region" aria-live="polite" aria-atomic="true" aria-labelledby="decryptedHeading" data-state="empty"></div>
      </div>
    </section>

    <div id="srStatus" role="status" aria-live="polite" class="visually-hidden"></div>

    <footer class="foot">
      <p>${cipherNames.length} historical ciphers wired up — one cipher per word, randomly selected.</p>
    </footer>
  `;
}

function announce(msg) {
  const el = document.getElementById('srStatus');
  if (!el) return;
  el.textContent = '';
  setTimeout(() => { el.textContent = msg; }, 30);
}

function encryptMessage() {
  const inputEl = document.getElementById('inputText');
  const outputEl = document.getElementById('outputText');
  const legendEl = document.getElementById('cipherLegend');
  const copyBtn = document.getElementById('copyEncryptBtn');
  const copyLegendBtn = document.getElementById('copyLegendBtn');
  const input = inputEl.value.trim();

  if (!input) {
    outputEl.innerHTML = '';
    legendEl.innerHTML = '';
    outputEl.setAttribute('data-state', 'empty');
    copyBtn.disabled = true;
    copyLegendBtn.disabled = true;
    return;
  }

  const words = input.split(/\s+/);
  const ciphersForWords = pickCiphersForWords(words.length);
  const legend = buildLegend(ciphersForWords);

  legendEl.innerHTML = legend
    .map(({ code, cipher }) => {
      return `<div class="legend-row"><dt><span class="badge">${escapeHtml(code)}</span></dt><dd>${escapeHtml(humanLabel(cipher))}</dd></div>`;
    })
    .join('');

  const plainTokens = [];
  const tokens = words.map((word, i) => {
    const cipher = ciphersForWords[i];
    const code = legend[i].code;
    let enc;
    try {
      enc = CipherEngines[cipher].encode(word, 'KEY');
      if (typeof enc !== 'string' || enc.length === 0) enc = word;
    } catch {
      enc = word;
    }
    plainTokens.push(enc);
    const safeEnc = escapeHtml(enc);
    const label = humanLabel(cipher);
    return `<span class="token" title="${escapeHtml(label)} (${escapeHtml(code)})">${safeEnc}</span>`;
  });

  outputEl.innerHTML = tokens.join(' <span class="token-sep" aria-hidden="true">|</span> ');
  outputEl.setAttribute('data-state', 'ready');
  outputEl.dataset.plain = plainTokens.join(' | ');
  legendEl.dataset.plain = legendToText(legend);
  copyBtn.disabled = false;
  copyLegendBtn.disabled = false;
  announce(`Encrypted ${words.length} word${words.length === 1 ? '' : 's'}.`);
}

function decryptMessage() {
  const text = document.getElementById('cipherText').value;
  const legendText = document.getElementById('legendInput').value;
  const key = document.getElementById('cipherKey').value || 'KEY';
  const outEl = document.getElementById('decryptedText');
  const copyBtn = document.getElementById('copyDecryptBtn');

  if (!text.trim()) {
    outEl.textContent = '';
    outEl.setAttribute('data-state', 'empty');
    copyBtn.disabled = true;
    return;
  }

  const legend = parseLegend(legendText);
  if (legend.length === 0) {
    outEl.textContent = 'No legend recognised. Paste the legend as e.g. "A: Caesar" (one per line).';
    outEl.setAttribute('data-state', 'error');
    copyBtn.disabled = true;
    return;
  }

  const { text: decoded, missingPositions } = decodeFromLegend(text, legend, key);
  if (missingPositions.length > 0) {
    outEl.textContent = `${decoded}  (legend missing entries for token${missingPositions.length === 1 ? '' : 's'} ${missingPositions.join(', ')})`;
    outEl.setAttribute('data-state', 'error');
    copyBtn.disabled = !decoded;
    return;
  }

  outEl.textContent = decoded || '(empty result)';
  outEl.setAttribute('data-state', decoded ? 'ready' : 'empty');
  copyBtn.disabled = !decoded;
  announce(`Decrypted ${legend.length} token${legend.length === 1 ? '' : 's'}.`);
}

async function copyToClipboard(text, btn) {
  if (!text) return;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'absolute';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    const original = btn.textContent;
    btn.textContent = 'Copied';
    btn.setAttribute('aria-pressed', 'true');
    announce('Copied to clipboard.');
    setTimeout(() => {
      btn.textContent = original;
      btn.removeAttribute('aria-pressed');
    }, 1500);
  } catch {
    announce('Copy failed.');
  }
}

function selectTab(target) {
  const tabs = document.querySelectorAll('[role="tab"]');
  tabs.forEach(tab => {
    const isActive = tab === target;
    tab.setAttribute('aria-selected', String(isActive));
    tab.setAttribute('tabindex', isActive ? '0' : '-1');
    const panelId = tab.getAttribute('aria-controls');
    const panel = document.getElementById(panelId);
    if (panel) panel.hidden = !isActive;
  });
  target.focus();
}

function wireTabs() {
  const tabs = Array.from(document.querySelectorAll('[role="tab"]'));
  tabs.forEach(tab => {
    tab.addEventListener('click', () => selectTab(tab));
    tab.addEventListener('keydown', e => {
      const idx = tabs.indexOf(tab);
      if (e.key === 'ArrowRight') { e.preventDefault(); selectTab(tabs[(idx + 1) % tabs.length]); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); selectTab(tabs[(idx - 1 + tabs.length) % tabs.length]); }
      else if (e.key === 'Home') { e.preventDefault(); selectTab(tabs[0]); }
      else if (e.key === 'End') { e.preventDefault(); selectTab(tabs[tabs.length - 1]); }
    });
  });
}

function wireEvents() {
  const $ = id => document.getElementById(id);

  $('encryptBtn').addEventListener('click', encryptMessage);
  $('clearBtn').addEventListener('click', () => {
    $('inputText').value = '';
    $('outputText').innerHTML = '';
    $('outputText').setAttribute('data-state', 'empty');
    $('outputText').dataset.plain = '';
    $('cipherLegend').innerHTML = '';
    $('cipherLegend').dataset.plain = '';
    $('copyEncryptBtn').disabled = true;
    $('copyLegendBtn').disabled = true;
    $('inputText').focus();
  });

  $('decryptBtn').addEventListener('click', decryptMessage);
  $('clearDecryptBtn').addEventListener('click', () => {
    $('cipherText').value = '';
    $('legendInput').value = '';
    $('cipherKey').value = '';
    $('decryptedText').textContent = '';
    $('decryptedText').setAttribute('data-state', 'empty');
    $('copyDecryptBtn').disabled = true;
    $('cipherText').focus();
  });

  $('copyEncryptBtn').addEventListener('click', () => {
    copyToClipboard($('outputText').dataset.plain || '', $('copyEncryptBtn'));
  });
  $('copyLegendBtn').addEventListener('click', () => {
    copyToClipboard($('cipherLegend').dataset.plain || '', $('copyLegendBtn'));
  });
  $('copyDecryptBtn').addEventListener('click', () => {
    copyToClipboard($('decryptedText').textContent, $('copyDecryptBtn'));
  });

  $('inputText').addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); encryptMessage(); }
  });
  $('cipherText').addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); decryptMessage(); }
  });
}

const appRoot = document.querySelector('#app');
if (appRoot) {
  render(appRoot);
  wireTabs();
  wireEvents();
}

export { encryptMessage, decryptMessage, copyToClipboard, selectTab };
