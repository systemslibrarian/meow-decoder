import puppeteer from 'puppeteer';

const URL = 'https://systemslibrarian.github.io/cipher-mix/';

const SIZES = [
  { width: 1242, height: 2688, out: 'screenshot-iphone-6.5.png' },
  { width: 2048, height: 2732, out: 'screenshot-ipad-13.png' },
];

const browser = await puppeteer.launch({
  args: ['--no-sandbox', '--disable-setuid-sandbox'],
});

for (const { width, height, out } of SIZES) {
  const page = await browser.newPage();
  await page.setViewport({ width, height, deviceScaleFactor: 1 });
  await page.goto(URL, { waitUntil: 'networkidle0', timeout: 30000 });
  await page.screenshot({ path: out, fullPage: false });
  await page.close();
  console.log(`Saved ${out} (${width}×${height})`);
}

await browser.close();
