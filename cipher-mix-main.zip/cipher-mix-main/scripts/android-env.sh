# Source this file (don't execute it) to set up the Android build env vars.
# Safe to re-source; idempotent.
#
# Usage:  source scripts/android-env.sh

if [ -d /usr/local/sdkman/candidates/java/21.0.10-ms ]; then
  export JAVA_HOME=/usr/local/sdkman/candidates/java/21.0.10-ms
elif [ -d /usr/lib/jvm/java-21-openjdk-amd64 ]; then
  export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
fi

export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/.android-sdk}"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:${JAVA_HOME:-}/bin:$PATH"

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")/.." && pwd)"
if [ -d "$REPO_ROOT/android" ] && [ ! -f "$REPO_ROOT/android/local.properties" ]; then
  echo "sdk.dir=$ANDROID_SDK_ROOT" > "$REPO_ROOT/android/local.properties"
fi
