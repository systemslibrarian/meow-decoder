#!/usr/bin/env bash
# Install Android command-line tools + the SDK packages this repo needs.
# Designed for a Linux environment (e.g. GitHub Codespaces, Ubuntu CI).
# Idempotent: re-running is fine.
#
# After running this once, source scripts/android-env.sh in any shell that
# needs to invoke gradle.

set -euo pipefail

ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/.android-sdk}"
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"

# JDK 21 — Android Gradle Plugin 8.x is incompatible with JDK 25, which is
# what the codespace ships by default. JDK 21 is provided via sdkman.
if [ -d /usr/local/sdkman/candidates/java/21.0.10-ms ]; then
  export JAVA_HOME=/usr/local/sdkman/candidates/java/21.0.10-ms
elif command -v /usr/lib/jvm/java-21-openjdk-amd64/bin/java >/dev/null 2>&1; then
  export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
else
  echo "WARNING: JDK 21 not found. Build may fail on AGP 8.x with newer JDKs." >&2
fi

mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"

if [ ! -d "$ANDROID_SDK_ROOT/cmdline-tools/latest" ]; then
  echo "Installing Android cmdline-tools to $ANDROID_SDK_ROOT…"
  tmp="$(mktemp -d)"
  curl -sSL -o "$tmp/cmdline-tools.zip" "$CMDLINE_TOOLS_URL"
  ( cd "$tmp" && unzip -q -o cmdline-tools.zip )
  mv "$tmp/cmdline-tools" "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  rm -rf "$tmp"
else
  echo "cmdline-tools already installed."
fi

export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:${JAVA_HOME:-}/bin:$PATH"

echo "Accepting SDK licences…"
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "Installing platform-tools, platforms;android-36, build-tools;36.0.0…"
sdkmanager "platform-tools" "platforms;android-36" "build-tools;36.0.0" >/dev/null

cat <<EOF

Android SDK ready.
  ANDROID_SDK_ROOT = $ANDROID_SDK_ROOT
  JAVA_HOME        = ${JAVA_HOME:-(unset)}

To use it in your shell now:
  source scripts/android-env.sh

To build a debug APK:
  npm run android:debug
EOF
