#!/usr/bin/env bash
# Build a sideload-able debug APK from this Linux machine. No Android Studio.
# Run scripts/setup-android-sdk.sh once first.

set -euo pipefail

cd "$(dirname "$0")/.."
# shellcheck disable=SC1091
source scripts/android-env.sh

echo "Building web bundle (relative paths) and syncing to android/…"
npm run cap:sync >/dev/null

echo "Running gradle assembleDebug…"
( cd android && ./gradlew --console=plain assembleDebug )

APK="android/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  size="$(du -h "$APK" | cut -f1)"
  echo
  echo "Debug APK built: $APK  ($size)"
  echo
  echo "To sideload onto a phone:"
  echo "  1. Enable Developer Options + USB debugging on the phone."
  echo "  2. Plug it in (or pair via wireless ADB)."
  echo "  3. Run:  adb install -r \"$APK\""
  echo "Or just upload the APK to Drive / iCloud and tap to install."
else
  echo "Build finished but APK not found at expected path." >&2
  exit 1
fi
