#!/usr/bin/env bash
# Build a release Android App Bundle (.aab) for the Play Store.
# Requires a signing keystore. Generate one ONCE with:
#
#   keytool -genkeypair -v \
#     -keystore ~/cipher-mix-release.jks \
#     -alias cipher-mix \
#     -keyalg RSA -keysize 2048 -validity 10000
#
# Then export the four env vars below before running this script
# (do NOT commit them — store them in a password manager):
#
#   export CM_KEYSTORE=~/cipher-mix-release.jks
#   export CM_KEYSTORE_PASSWORD=...
#   export CM_KEY_ALIAS=cipher-mix
#   export CM_KEY_PASSWORD=...
#
# This script wires the keystore into Gradle for one build only and never
# writes secrets to disk.

set -euo pipefail

cd "$(dirname "$0")/.."
# shellcheck disable=SC1091
source scripts/android-env.sh

: "${CM_KEYSTORE:?CM_KEYSTORE not set — see header of this script}"
: "${CM_KEYSTORE_PASSWORD:?CM_KEYSTORE_PASSWORD not set}"
: "${CM_KEY_ALIAS:?CM_KEY_ALIAS not set}"
: "${CM_KEY_PASSWORD:?CM_KEY_PASSWORD not set}"

echo "Building web bundle and syncing…"
npm run cap:sync >/dev/null

echo "Running gradle bundleRelease…"
( cd android && ./gradlew --console=plain \
    -Pandroid.injected.signing.store.file="$CM_KEYSTORE" \
    -Pandroid.injected.signing.store.password="$CM_KEYSTORE_PASSWORD" \
    -Pandroid.injected.signing.key.alias="$CM_KEY_ALIAS" \
    -Pandroid.injected.signing.key.password="$CM_KEY_PASSWORD" \
    bundleRelease )

AAB="android/app/build/outputs/bundle/release/app-release.aab"
if [ -f "$AAB" ]; then
  size="$(du -h "$AAB" | cut -f1)"
  echo
  echo "Signed AAB built: $AAB  ($size)"
  echo "Upload this file to the Play Console under Production > Create release."
else
  echo "bundleRelease finished but AAB not found." >&2
  exit 1
fi
