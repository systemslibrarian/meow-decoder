# Releasing to TestFlight via GitHub Actions

The workflow at [`.github/workflows/release.yml`](../.github/workflows/release.yml)
spins up a macOS runner, builds Cipher Mix as an iOS app from this codebase,
and uploads it to TestFlight. Once a build is on TestFlight you can promote
it to the App Store from App Store Connect with a click.

## When the workflow runs

- **On push of a tag** matching `v*` (e.g. `git tag v1.0.0 && git push --tags`).
- **On manual dispatch** from the Actions tab — useful for the first time
  through, or for re-running with a build number override.

## The seven required secrets

You set these once at **Settings → Secrets and variables → Actions →
New repository secret**. The workflow won't run successfully until all
seven are present.

| Secret | What it is | How to get it |
|---|---|---|
| `BUILD_CERTIFICATE_BASE64` | base64 of your `certificate.p12` | `base64 -i certificate.p12 \| pbcopy` (macOS) or `base64 certificate.p12` then copy the entire output. |
| `P12_PASSWORD` | password you set when running `openssl pkcs12 -export` | Whatever you typed when creating the .p12. |
| `BUILD_PROVISION_PROFILE_BASE64` | base64 of your iOS App Store provisioning profile | See "Creating the provisioning profile" below. Then `base64 < ProfileName.mobileprovision`. |
| `KEYCHAIN_PASSWORD` | random password used to spin up a temporary keychain on the runner | Any string. `openssl rand -base64 24` is fine. Used only by CI; doesn't matter what you pick. |
| `APPLE_ID` | the email on your Apple Developer account | The address you sign in with. |
| `AC_PASSWORD` | App-specific password for `altool` upload | https://account.apple.com → **Sign-In and Security → App-Specific Passwords → +**. Generate one named "Cipher Mix CI". |
| `APPLE_TEAM_ID` | 10-character team identifier | https://developer.apple.com/account → **Membership** → **Team ID**. Looks like `ABCDE12345`. |

## Creating the provisioning profile (one time)

The cert says "this signing key is valid". The profile says "this cert is
allowed to sign **this bundle ID** for **App Store distribution**".

1. https://developer.apple.com/account → **Certificates, Identifiers & Profiles**.
2. **Identifiers** → **+** → **App IDs** → **App** → register
   `com.systemslibrarian.ciphermix` (description: Cipher Mix). No special
   capabilities needed.
3. **Profiles** → **+** → **Distribution → App Store** → next.
4. App ID: `com.systemslibrarian.ciphermix`.
5. Certificate: pick the Apple Distribution cert you created earlier.
6. Profile Name: `Cipher Mix App Store` (or anything — the workflow looks
   it up by UUID at runtime, not by name).
7. **Generate** → **Download**. You get a `.mobileprovision` file.
8. `base64 -i Cipher_Mix_App_Store.mobileprovision | pbcopy` and paste
   into `BUILD_PROVISION_PROFILE_BASE64`.

If you ever change the bundle ID, regenerate the profile.

## Creating the App Store Connect entry (one time)

Before TestFlight will accept an upload:

1. https://appstoreconnect.apple.com → **My Apps** → **+** → **New App**.
2. Platform: **iOS**.
3. Name: **Cipher Mix**.
4. Primary Language: English.
5. Bundle ID: pick `com.systemslibrarian.ciphermix` from the dropdown
   (will only appear after step 2 of "Creating the provisioning profile"
   above).
6. SKU: anything unique, e.g. `cipher-mix-001`.

Until this exists the workflow will archive and export fine but the upload
step will fail with "No App Store Connect record found".

## Triggering the first run

```bash
# Tag triggers the release
git tag v0.1.0
git push origin v0.1.0
```

…or open **Actions → Release iOS to TestFlight → Run workflow**.

## What the workflow does

1. Checks out the repo, runs `npm ci`, `npm test` (the 58-test suite gates
   every release).
2. Runs `npm run build:native` then `npx cap sync ios` to refresh the
   native iOS project with the latest web bundle.
3. Decodes the `.p12` cert into a temporary keychain and the
   `.mobileprovision` into the runner's profile directory. Extracts the
   profile UUID and name from the binary so `ExportOptions.plist` can be
   filled in without an extra secret.
4. Stamps `CFBundleVersion` with the workflow run number so every build
   has a unique build number (TestFlight rejects duplicates).
5. `xcodebuild archive` with manual signing pinned to your team and
   profile UUID.
6. `xcodebuild -exportArchive` with the rendered `ExportOptions.plist`.
7. `xcrun altool --upload-app` ships the IPA to App Store Connect →
   TestFlight.
8. Uploads the IPA as a workflow artifact (kept 14 days) so you can
   download it from the run page if anything's odd.

## After the upload

Apple's server-side processing takes 5–30 minutes. You'll get an email
when it's ready. Then:

- **TestFlight tab** in App Store Connect → add an internal test group →
  share the link with friends to test before public release.
- **App Store tab** → fill in the listing (description, keywords,
  screenshots, privacy policy URL — see [STORES.md](../STORES.md)) →
  submit for review when you're ready.

## Troubleshooting

- **"No signing certificate matching X found"** — the cert in your
  keychain doesn't match what the provisioning profile lists. Re-export
  the .p12 from Keychain Access making sure to include the private key.
- **"Provisioning profile X doesn't include signing certificate"** —
  same, but expressed differently. Regenerate the provisioning profile
  in the Developer Portal after adding the cert.
- **"App Store Connect Operation Error: ITMS-90034: Missing signing"** —
  bundle ID mismatch between Info.plist and the provisioning profile.
  Verify both say `com.systemslibrarian.ciphermix`.
- **Build number conflict** — TestFlight rejects duplicate
  `CFBundleVersion`. Re-run with a higher number via the manual dispatch
  input, or push a new tag.
