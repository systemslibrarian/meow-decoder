# Cipher Mix — TestFlight Setup Progress

## Overall Status: In Progress 🟡

---

## ✅ Completed Steps

### 1. Apple Developer Portal — App ID Registered
- Bundle ID: `com.systemslibrarian.ciphermix`
- Registered under: Paul Clark (`KLBJ3RJ6X8`)

### 2. Provisioning Profile Created
- Profile Name: `Cipher Mix App Store`
- Type: App Store Connect (Distribution)
- Downloaded: `Cipher_Mix_App_Store.mobileprovision`
- Expires: 2027-04-30

### 3. Provisioning Profile Base64-Encoded
- Encoded without a Mac — done directly in Claude
- Output file: `BUILD_PROVISION_PROFILE_BASE64.txt`
- Ready to paste into GitHub secret

### 4. Team ID Identified
- Extracted from provisioning profile
- Value: `KLBJ3RJ6X8`

---

## 🔲 GitHub Secrets Status

| Secret | Status | Notes |
|---|---|---|
| `BUILD_PROVISION_PROFILE_BASE64` | ✅ Ready to add | Downloaded from Claude |
| `APPLE_TEAM_ID` | ✅ Known | `KLBJ3RJ6X8` |
| `BUILD_CERTIFICATE_BASE64` | ⏳ Next step | Requires .p12 — see below |
| `P12_PASSWORD` | ⏳ Pending | Set when creating .p12 |
| `KEYCHAIN_PASSWORD` | ⏳ Pending | Any random string |
| `APPLE_ID` | ⏳ Pending | Your Apple Developer email |
| `AC_PASSWORD` | ⏳ Pending | App-specific password from account.apple.com |

---

## ⏳ Next Steps

### Step A — Check Existing Certificates
Go to [developer.apple.com/account](https://developer.apple.com/account) →
Certificates, Identifiers & Profiles → **Certificates**

- **If an "Apple Distribution" cert exists** → it may need to be revoked and regenerated (private key is needed for .p12, and Apple doesn't store it)
- **If no cert exists** → proceed to Step B

### Step B — Generate Certificate (No Mac Needed)
Claude can generate the following directly in chat:
1. Private key + CSR (Certificate Signing Request)
2. You upload the CSR to Apple Developer Portal
3. Apple issues the Distribution certificate
4. Claude packages private key + cert into a `.p12`
5. Claude base64-encodes the `.p12` → ready for GitHub secret

### Step C — Remaining Secrets
After the certificate is done:
- **`KEYCHAIN_PASSWORD`** — Claude can generate a random one
- **`APPLE_ID`** — you provide your Apple Developer email
- **`AC_PASSWORD`** — generate at [account.apple.com](https://account.apple.com) → Sign-In and Security → App-Specific Passwords → +, name it `Cipher Mix CI`

### Step D — App Store Connect Entry
Before the first upload will succeed, create the app record:
1. Go to [appstoreconnect.apple.com](https://appstoreconnect.apple.com)
2. My Apps → + → New App
3. Platform: iOS | Name: Cipher Mix
4. Bundle ID: `com.systemslibrarian.ciphermix`
5. SKU: `cipher-mix-001`

### Step E — First Build Trigger
Once all 7 secrets are in GitHub:
```bash
git tag v0.1.0
git push origin v0.1.0
```
Or use **Actions → Release iOS to TestFlight → Run workflow** for a manual trigger.

---

## Reference

| Item | Value |
|---|---|
| Bundle ID | `com.systemslibrarian.ciphermix` |
| Team ID | `KLBJ3RJ6X8` |
| Profile Name | Cipher Mix App Store |
| Profile Expiry | 2027-04-30 |
| App SKU (suggested) | `cipher-mix-001` |