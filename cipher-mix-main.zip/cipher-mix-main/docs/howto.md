# Publishing an iOS App Without a Mac — Complete Walkthrough

This is a full record of how Cipher Mix was published to the Apple App Store
entirely from a GitHub Codespace (Linux), with no Mac involved at any step.
Every workaround, gotcha, and fix is documented here so it can be repeated.

---

## The Core Challenge

Apple's normal publishing flow assumes you own a Mac running Xcode. Without
one you cannot:
- Generate a signing certificate the normal way (Keychain Access)
- Build or archive the app locally
- Upload the IPA with Xcode Organizer

**The workaround:** do everything in a GitHub Codespace + GitHub Actions.
The Codespace handles certificate generation (via OpenSSL) and secret
management. GitHub Actions provides the macOS runner with Xcode for the
actual build, sign, and upload.

---

## Part 1: Apple Developer Portal Setup

### 1.1 — Register the App ID

1. Go to developer.apple.com/account → Certificates, Identifiers & Profiles
   → Identifiers → **+** → App IDs → App
2. Enter a description and set the Bundle ID to `com.systemslibrarian.ciphermix`
3. No special capabilities needed — click Continue → Register

**Gotcha we hit:** The original App ID had a trailing period
(`com.systemslibrarian.ciphermix.`). This silently broke the provisioning
profile because the Bundle ID in the profile didn't match the one in the
project. Fix: delete the bad identifier and re-register with the clean ID.

### 1.2 — Generate a Distribution Certificate Without a Mac

Normally you'd use Keychain Access on a Mac to generate a CSR. In a
Codespace, use OpenSSL instead:

```bash
# Generate a private key
openssl genrsa -out mykey.key 2048

# Generate the CSR
openssl req -new -key mykey.key -out cipher-mix.csr \
  -subj "/emailAddress=systemslibrarian@gmail.com/CN=Paul Clark/C=US"
```

Then:
1. Go to Apple Developer Portal → Certificates → **+** → Apple Distribution
2. Upload `cipher-mix.csr`
3. Download the issued `distribution.cer`

Package the key + cert into a `.p12` that the CI workflow can import:

```bash
# Convert .cer to .pem
openssl x509 -in distribution.cer -inform DER -out distribution.pem -outform PEM

# Bundle into .p12 (choose a password — used as P12_PASSWORD secret)
openssl pkcs12 -export -out certificate.p12 \
  -inkey mykey.key -in distribution.pem \
  -passout pass:YourPasswordHere

# Base64-encode for GitHub secret
base64 -i certificate.p12 | tr -d '\n'
```

Paste the base64 output into the `BUILD_CERTIFICATE_BASE64` GitHub secret.

**Important:** After encoding, delete or gitignore the raw key and cert files.
They are credentials — never commit them.

### 1.3 — Create the Provisioning Profile

1. Go to Certificates, Identifiers & Profiles → Profiles → **+**
2. Select: Distribution → **App Store Connect**
3. Select the App ID: `com.systemslibrarian.ciphermix`
4. Select the Distribution certificate you just created
5. Name it (e.g. `Cipher Mix App Store`) → Generate → Download

Encode it for GitHub:
```bash
base64 -i CipherMixAppStore.mobileprovision | tr -d '\n'
```

Paste into `BUILD_PROVISION_PROFILE_BASE64` GitHub secret.

**Gotcha we hit:** After revoking and recreating the certificate, the
provisioning profile must also be regenerated — it is cryptographically
linked to the cert. Updating the cert secret alone is not enough.

### 1.4 — Create the App Store Connect Entry

1. Go to appstoreconnect.apple.com → My Apps → **+** → New App
2. Platform: **iOS** | Name: Cipher Mix | Language: English
3. Bundle ID: `com.systemslibrarian.ciphermix` (from dropdown)
4. SKU: `cipher-mix-001`
5. User Access: Full Access → **Create**

The app must exist in App Store Connect before any upload will succeed.
App ID assigned: `6765497338`

### 1.5 — Create an App Store Connect API Key

Apple deprecated username+password authentication for `altool` in Xcode 16.
You need an API key instead.

1. Go to appstoreconnect.apple.com → Users and Access → Integrations
   → **App Store Connect API**
2. Click **+** → Name: `cipher-mix-ci` → Access: **Developer** → Generate
3. **Download the `.p8` file immediately** — it is only shown once
4. Note the **Key ID** (e.g. `N7SFL234VZ`) and **Issuer ID** (UUID at top)

Encode the key for GitHub:
```bash
base64 -i AuthKey_N7SFL234VZ.p8 | tr -d '\n'
```

Add three secrets: `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_PRIVATE_KEY`.

---

## Part 2: GitHub Secrets

All secrets live at: github.com/systemslibrarian/cipher-mix → Settings →
Secrets and variables → Actions

### Complete secrets list

| Secret | What it is | How to get it |
|---|---|---|
| `BUILD_CERTIFICATE_BASE64` | Apple Distribution cert (.p12) base64 | See 1.2 above |
| `P12_PASSWORD` | Password chosen when creating the .p12 | See 1.2 above |
| `BUILD_PROVISION_PROFILE_BASE64` | Provisioning profile base64 | See 1.3 above |
| `APPLE_TEAM_ID` | Your 10-char developer team ID | developer.apple.com → Membership |
| `KEYCHAIN_PASSWORD` | Any random string — used for the CI temp keychain | Generate any password |
| `ASC_KEY_ID` | App Store Connect API Key ID | `N7SFL234VZ` — see 1.5 above |
| `ASC_ISSUER_ID` | App Store Connect Issuer ID (UUID) | See 1.5 above |
| `ASC_PRIVATE_KEY` | base64 of the .p8 API key file | See 1.5 above |

**Retired secrets** (no longer used, can be deleted):
- `APPLE_ID` — Apple shut down username+password auth for altool in Xcode 16
- `AC_PASSWORD` — same reason

---

## Part 3: The Release Workflow

The workflow lives at `.github/workflows/release.yml` and triggers on any
`v*` tag push. To release a new version:

```bash
git tag v0.x.y
git push origin v0.x.y
```

### Workflow fixes applied (and why)

**Fix 1: Force Apple Distribution identity**
Capacitor scaffolds projects with `CODE_SIGN_IDENTITY = "iPhone Developer"`.
This causes Xcode to look for a development cert, not a distribution cert,
and the archive fails. Override it on the command line:
```
CODE_SIGN_IDENTITY="Apple Distribution"
```

**Fix 2: Keychain setup**
The temp keychain must be set as the default and `codesign` must be told
where to find it explicitly via `OTHER_CODE_SIGN_FLAGS`:
```
OTHER_CODE_SIGN_FLAGS="--keychain $RUNNER_TEMP/build.keychain-db"
```
Also install the Apple WWDR G3 intermediate cert into the temp keychain so
the certificate chain resolves without depending on system state.

**Fix 3: API key auth for upload**
Switch from the dead username+password method to App Store Connect API key.
`altool` in Xcode 16 expects the key file at `~/.private_keys/AuthKey_{KEY_ID}.p8`:
```bash
mkdir -p ~/.private_keys
echo -n "$ASC_PRIVATE_KEY" | base64 --decode > ~/.private_keys/AuthKey_${ASC_KEY_ID}.p8
xcrun altool --upload-app -f "$IPA_PATH" -t ios \
    --apiKey "$ASC_KEY_ID" --apiIssuer "$ASC_ISSUER_ID"
```

**Fix 4: iOS 26 SDK requirement**
As of 2026, Apple requires all uploads to be built with the iOS 26 SDK
(Xcode 26). The `macos-latest` runner only has Xcode 16.4 / iOS 18.5 SDK
and uploads are rejected. Fix: use `runs-on: macos-26`.

---

## Part 4: App-Specific Requirements for Cipher Mix

### Encryption Export Compliance
Cipher Mix is a cryptography app, which triggers Apple's encryption export
compliance review. To avoid having to answer this manually on every
submission, add this key to `ios/App/App/Info.plist`:

```xml
<key>ITSAppUsesNonExemptEncryption</key>
<false/>
```

Cipher Mix uses only standard WebCrypto API algorithms (AES, etc.) which
qualify for the EAR exemption — hence `false`. Apple reads this from the
build automatically.

### Privacy Policy
Apple requires a privacy policy URL for all App Store apps. Since Cipher Mix
collects no data and makes no network requests, the policy is very simple.

- Source: `public/privacy.html` (Vite copies it to `dist/` as-is)
- Live URL: https://systemslibrarian.github.io/cipher-mix/privacy.html
- Use this URL in the App Store listing's Privacy Policy URL field

---

## Part 5: App Store Screenshots (No Mac)

Since there's no Mac to run the Simulator, screenshots are generated
automatically from the live GitHub Pages URL using Puppeteer.

**Workflow:** `.github/workflows/screenshot.yml` — runs on every push to main
**Script:** `screenshot.mjs`

The script opens the live site in a headless browser at each required
resolution and saves PNG files. Download the **appstore-screenshots**
artifact from the Actions run.

| File | Size | App Store slot |
|---|---|---|
| `screenshot-iphone-6.5.png` | 1242 × 2688 | iPhone 6.5" |
| `screenshot-ipad-13.png` | 2048 × 2732 | iPad 13-inch |

---

## Part 6: Completing the App Store Listing

In App Store Connect → your app → App Store tab → 1.0 Prepare for Submission:

1. **Screenshots** — upload from the artifact above to each device slot
2. **Description** — what the app does
3. **Keywords** — comma-separated, max 100 chars
4. **Support URL** — can use https://systemslibrarian.github.io/cipher-mix/
5. **Privacy Policy URL** — https://systemslibrarian.github.io/cipher-mix/privacy.html
6. **Build** — click **+** next to Build, select `1.0 (17)` (or latest)
7. **Submit for Review**

---

## Reference

| Item | Value |
|---|---|
| Bundle ID | `com.systemslibrarian.ciphermix` |
| Team ID | `KLBJ3RJ6X8` |
| App Store Connect App ID | `6765497338` |
| ASC API Key ID | `N7SFL234VZ` |
| Profile Name | Cipher Mix App Store |
| Profile Expiry | 2027-04-30 |
| App SKU | `cipher-mix-001` |
| Apple Developer Account | Paul Clark |
| Privacy Policy URL | https://systemslibrarian.github.io/cipher-mix/privacy.html |
| GitHub Pages URL | https://systemslibrarian.github.io/cipher-mix/ |
| Actions URL | https://github.com/systemslibrarian/cipher-mix/actions |
