import { describe, it, expect } from 'vitest';
import { CipherEngines } from '../src/ciphers/all-engines.js';

const EXPECTED_COUNT = 84;
const SAMPLE = 'HELLOWORLD';
const KEY = 'KEY';

// Empirically derived: the 75 ciphers below round-trip exactly on the sample
// 'HELLOWORLD' with key 'KEY'. The remaining 9 are intentionally non-lossless
// on a single sample (homophonic, hill, otp, vernam, babington use random or
// pad-management; scytale, beale, dictionaryCode, cardanoGrille need
// length-/dictionary-specific inputs). They are still tested for non-throwing
// encode/decode below.
const STRICT_ROUNDTRIP = new Set([
  'caesar', 'monoalphabetic', 'polybius', 'playfair', 'vigenere', 'beaufort',
  'gronsfeld', 'porta', 'runningKey', 'railFence', 'columnar',
  'doubleTransposition', 'bacon', 'tapCode', 'pigpen', 'bifid', 'trifid',
  'adfgx', 'adfgvx', 'nihilist', 'venonaPadReuse', 'fractionatedMorse',
  'confederateVigenere', 'bazeries', 'alberti', 'jefferson', 'enigma',
  'lorenz', 'stager', 'vic', 'scytale', 'greatCipher', 'navajo', 'voynich',
  'atbash', 'rot13', 'foursquare', 'twosquare', 'straddlingCheckerboard',
  'chaocipher', 'm209', 'solitaire', 'copiale', 'kryptos', 'purple',
  'autokey', 'nomenclator', 'bookCipher', 'sigaba', 'typex', 'kamaSutra',
  'aeneasTacticus', 'jn25', 'redTypeA', 'affine', 'trithemius',
  'cardanoAutokey', 'wheatstone', 'morse', 'cardanoGrille', 'nullCipher',
  'fialka', 'kl7', 'geheimschreiber', 'kryha', 'm94', 'chineseTelegraph',
  'zimmermann', 'slidex', 'commercialCode', 'culperRing', 'arnoldAndre',
  'argenti', 'wallisCiphers', 'joseonYeokhak', 'geezMonastic', 'diana',
]);

const PAD_PRONE = ['stager', 'scytale', 'foursquare', 'twosquare', 'slidex', 'cardanoGrille'];

describe('CipherEngines registry', () => {
  it(`registers exactly ${EXPECTED_COUNT} ciphers`, () => {
    expect(Object.keys(CipherEngines).length).toBe(EXPECTED_COUNT);
  });

  it('also exposes the registry on globalThis for browser-globals consumers', () => {
    expect(globalThis.CipherEngines).toBe(CipherEngines);
  });

  it('every cipher exposes encode and decode functions', () => {
    for (const [name, engine] of Object.entries(CipherEngines)) {
      expect(engine, `${name} should be defined`).toBeTruthy();
      expect(typeof engine.encode, `${name}.encode`).toBe('function');
      expect(typeof engine.decode, `${name}.decode`).toBe('function');
    }
  });

  it('every cipher encodes a sample without throwing or returning empty', () => {
    const failures = [];
    for (const [name, engine] of Object.entries(CipherEngines)) {
      try {
        const out = engine.encode(SAMPLE, KEY);
        if (typeof out !== 'string' || out.length === 0) {
          failures.push(`${name}: returned ${typeof out} (${JSON.stringify(out)})`);
        }
      } catch (err) {
        failures.push(`${name}: threw ${err.message}`);
      }
    }
    expect(failures, failures.join('\n')).toEqual([]);
  });

  it('every cipher decodes its own output without throwing', () => {
    const failures = [];
    for (const [name, engine] of Object.entries(CipherEngines)) {
      try {
        const enc = engine.encode(SAMPLE, KEY);
        const dec = engine.decode(enc, KEY);
        if (typeof dec !== 'string') {
          failures.push(`${name}: decode returned ${typeof dec}`);
        }
      } catch (err) {
        failures.push(`${name}: ${err.message}`);
      }
    }
    expect(failures, failures.join('\n')).toEqual([]);
  });

  it(`${STRICT_ROUNDTRIP.size} ciphers strictly round-trip — decode(encode(x))===x`, () => {
    expect(STRICT_ROUNDTRIP.size).toBeGreaterThanOrEqual(75);
    const failures = [];
    for (const name of STRICT_ROUNDTRIP) {
      const engine = CipherEngines[name];
      expect(engine, `cipher ${name} must exist in registry`).toBeTruthy();
      const enc = engine.encode(SAMPLE, KEY);
      const dec = engine.decode(enc, KEY);
      const normalized = String(dec).toUpperCase().replace(/[^A-Z]/g, '');
      if (normalized !== SAMPLE) {
        failures.push(`${name}: ${SAMPLE} → ${enc} → ${dec} (normalized: ${normalized})`);
      }
    }
    expect(failures, failures.join('\n')).toEqual([]);
  });

  it('strict-roundtrip set only references real ciphers', () => {
    for (const name of STRICT_ROUNDTRIP) {
      expect(CipherEngines, `${name} should be registered`).toHaveProperty(name);
    }
  });

  it('pad-prone ciphers strip filler X on decode for short inputs', () => {
    // Regression for: short words like "LOVE" used to come back as "LOVEX"
    // because grid-based ciphers (Stager, Scytale, Four-/Two-Square, Slidex,
    // Cardano Grille) padded with X to fill the grid and didn't strip on
    // decode.
    const failures = [];
    for (const name of PAD_PRONE) {
      const eng = CipherEngines[name];
      for (const word of ['LOVE', 'HI', 'YOU', 'ATTACK']) {
        const enc = eng.encode(word, 'KEY');
        const dec = String(eng.decode(enc, 'KEY')).toUpperCase().replace(/[^A-Z]/g, '');
        if (dec !== word) {
          failures.push(`${name}: ${word} → ${enc} → ${dec}`);
        }
      }
    }
    expect(failures, failures.join('\n')).toEqual([]);
  });
});

describe('Cipher names', () => {
  it('names are unique camelCase identifiers', () => {
    const names = Object.keys(CipherEngines);
    expect(new Set(names).size).toBe(names.length);
    for (const n of names) {
      expect(n, `${n}`).toMatch(/^[a-zA-Z][a-zA-Z0-9]*$/);
    }
  });
});
