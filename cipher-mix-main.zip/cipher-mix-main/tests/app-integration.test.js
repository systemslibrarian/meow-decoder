// @vitest-environment jsdom
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { CipherEngines } from '../src/ciphers/all-engines.js';

const EXPECTED_COUNT = 84;

function setupDom() {
  document.body.innerHTML = `
    <a class="skip-link" href="#inputText">Skip to message input</a>
    <main id="app" aria-labelledby="appTitle"></main>
  `;
}

describe('App integration', () => {
  let main;

  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    main = await import('../src/main.js');
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('renders app shell with required landmarks, labels, tabs, and instructions', () => {
    expect(document.getElementById('appTitle')).not.toBeNull();
    expect(document.querySelector('label[for="inputText"]')).not.toBeNull();
    expect(document.querySelector('label[for="cipherText"]')).not.toBeNull();
    expect(document.querySelector('label[for="legendInput"]')).not.toBeNull();
    expect(document.querySelector('label[for="cipherKey"]')).not.toBeNull();

    expect(document.querySelectorAll('.howto').length).toBe(2);

    const tabs = document.querySelectorAll('[role="tab"]');
    expect(tabs.length).toBe(2);

    const output = document.getElementById('outputText');
    expect(output.getAttribute('aria-live')).toBe('polite');
    expect(output.getAttribute('role')).toBe('region');
  });

  it('encrypts each word and renders a per-position legend (one row per word)', () => {
    document.getElementById('inputText').value = 'hello world from cipher mix';
    document.getElementById('encryptBtn').click();

    const tokens = document.querySelectorAll('#outputText .token');
    expect(tokens.length).toBe(5);
    for (const t of tokens) {
      expect(t.textContent).not.toMatch(/\[[A-Z]+\]/);
    }

    // One legend row per token, every code is a 1-3 letter sequence drawn
    // from the stable global cipher↔code map.
    const rows = document.querySelectorAll('#cipherLegend .legend-row');
    expect(rows.length).toBe(5);
    for (const r of rows) {
      expect(r.querySelector('.badge').textContent).toMatch(/^[A-Z]{1,3}$/);
    }
  });

  it('plain ciphertext copy is just tokens separated by " | " — no codes', () => {
    document.getElementById('inputText').value = 'hello world';
    document.getElementById('encryptBtn').click();
    const plain = document.getElementById('outputText').dataset.plain;
    expect(plain).not.toMatch(/\[[A-Z]+\]/);
    expect(plain.split(' | ').length).toBe(2);
  });

  it('shows numbered step indicators and a "send both" callout on the encrypt panel', () => {
    expect(document.querySelectorAll('#encryptPanel .step-num').length).toBeGreaterThanOrEqual(2);
    const callout = document.querySelector('#encryptPanel .callout');
    expect(callout).not.toBeNull();
    expect(callout.textContent.toLowerCase()).toContain('send both');
  });

  it('encrypt and decrypt action buttons are prominent and visually distinct', () => {
    const enc = document.getElementById('encryptBtn');
    const dec = document.getElementById('decryptBtn');
    expect(enc.classList.contains('btn-primary')).toBe(true);
    expect(dec.classList.contains('btn-primary')).toBe(true);
    expect(dec.classList.contains('btn-decrypt')).toBe(true);
    // Each carries a clear, descriptive label (not just "Encrypt"/"Decrypt").
    expect(enc.textContent.toLowerCase()).toContain('encrypt message');
    expect(dec.textContent.toLowerCase()).toContain('decrypt message');
  });

  it('clear and copy buttons use the secondary/ghost styles, not primary', () => {
    expect(document.getElementById('clearBtn').classList.contains('btn-secondary')).toBe(true);
    expect(document.getElementById('clearDecryptBtn').classList.contains('btn-secondary')).toBe(true);
    for (const id of ['copyEncryptBtn', 'copyLegendBtn', 'copyDecryptBtn']) {
      expect(document.getElementById(id).classList.contains('btn-ghost'),
        `${id} should be a ghost button`).toBe(true);
    }
  });

  it('humanLabel applies overrides for acronyms and accented names', () => {
    expect(main.humanLabel('m209')).toBe('M-209');
    expect(main.humanLabel('kl7')).toBe('KL-7');
    expect(main.humanLabel('jn25')).toBe('JN-25');
    expect(main.humanLabel('m94')).toBe('M-94');
    expect(main.humanLabel('vigenere')).toBe('Vigenère');
    expect(main.humanLabel('rot13')).toBe('ROT13');
    expect(main.humanLabel('otp')).toBe('One-Time Pad');
    expect(main.humanLabel('sigaba')).toBe('SIGABA');
    expect(main.humanLabel('adfgvx')).toBe('ADFGVX');
    expect(main.humanLabel('arnoldAndre')).toBe('Arnold–André');
    expect(main.humanLabel('runningKey')).toBe('Running Key');
    expect(main.humanLabel('caesar')).toBe('Caesar');
  });

  it('clear button resets the input and output and disables copy', () => {
    document.getElementById('inputText').value = 'hello';
    document.getElementById('encryptBtn').click();
    expect(document.getElementById('outputText').textContent.length).toBeGreaterThan(0);
    expect(document.getElementById('copyEncryptBtn').disabled).toBe(false);
    expect(document.getElementById('copyLegendBtn').disabled).toBe(false);

    document.getElementById('clearBtn').click();
    expect(document.getElementById('inputText').value).toBe('');
    expect(document.getElementById('outputText').textContent).toBe('');
    expect(document.getElementById('copyEncryptBtn').disabled).toBe(true);
    expect(document.getElementById('copyLegendBtn').disabled).toBe(true);
  });

  it('exposes all 84 cipher names via main module', () => {
    expect(main.cipherNames.length).toBe(EXPECTED_COUNT);
    expect(new Set(main.cipherNames).size).toBe(EXPECTED_COUNT);
  });

  it('every one of the 84 ciphers is reachable through pickCiphersForWords', () => {
    const rand = vi.spyOn(Math, 'random').mockReturnValue(0);
    try {
      const ciphers = main.pickCiphersForWords(EXPECTED_COUNT);
      const registry = Object.keys(CipherEngines);
      expect(new Set(ciphers).size).toBe(EXPECTED_COUNT);
      for (const name of registry) {
        expect(ciphers).toContain(name);
      }
    } finally {
      rand.mockRestore();
    }
  });

  it('every one of the 84 ciphers actually fires through the UI', () => {
    const rand = vi.spyOn(Math, 'random').mockReturnValue(0);
    try {
      const words = Array.from({ length: EXPECTED_COUNT }, (_, i) => `word${i}`);
      document.getElementById('inputText').value = words.join(' ');
      document.getElementById('encryptBtn').click();

      const tokens = document.querySelectorAll('#outputText .token');
      expect(tokens.length).toBe(EXPECTED_COUNT);

      const legendRows = document.querySelectorAll('#cipherLegend .legend-row');
      expect(legendRows.length).toBe(EXPECTED_COUNT);

      const labels = Array.from(legendRows).map(r => r.querySelector('dd').textContent);
      const expectedLabels = Object.keys(CipherEngines).map(main.humanLabel);
      for (const label of expectedLabels) {
        expect(labels).toContain(label);
      }
    } finally {
      rand.mockRestore();
    }
  });

  it('handles empty input gracefully', () => {
    document.getElementById('inputText').value = '   ';
    document.getElementById('encryptBtn').click();
    expect(document.getElementById('outputText').textContent).toBe('');
  });

  it('escapes HTML in user input to avoid XSS', () => {
    document.getElementById('inputText').value = '<script>alert(1)</script>';
    document.getElementById('encryptBtn').click();
    const html = document.getElementById('outputText').innerHTML;
    expect(html).not.toContain('<script>');
  });
});

describe('Tabs (ARIA pattern)', () => {
  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    await import('../src/main.js');
  });

  it('only one tab is selected at a time and only the selected panel is visible', () => {
    const e = document.getElementById('encryptTab');
    const d = document.getElementById('decryptTab');
    const ep = document.getElementById('encryptPanel');
    const dp = document.getElementById('decryptPanel');

    expect(e.getAttribute('aria-selected')).toBe('true');
    expect(d.getAttribute('aria-selected')).toBe('false');
    expect(ep.hidden).toBe(false);
    expect(dp.hidden).toBe(true);

    d.click();
    expect(e.getAttribute('aria-selected')).toBe('false');
    expect(d.getAttribute('aria-selected')).toBe('true');
    expect(ep.hidden).toBe(true);
    expect(dp.hidden).toBe(false);
  });

  it('arrow-key navigation moves between tabs', () => {
    const e = document.getElementById('encryptTab');
    const d = document.getElementById('decryptTab');
    e.focus();
    e.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true }));
    expect(d.getAttribute('aria-selected')).toBe('true');
    d.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowLeft', bubbles: true }));
    expect(e.getAttribute('aria-selected')).toBe('true');
  });

  it('roving tabindex: only the selected tab is in the tab order', () => {
    const e = document.getElementById('encryptTab');
    const d = document.getElementById('decryptTab');
    expect(e.getAttribute('tabindex')).toBe('0');
    expect(d.getAttribute('tabindex')).toBe('-1');
    d.click();
    expect(e.getAttribute('tabindex')).toBe('-1');
    expect(d.getAttribute('tabindex')).toBe('0');
  });
});

describe('Legend parsing + decoding', () => {
  let main;

  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    main = await import('../src/main.js');
  });

  it('parseLegend returns ciphers in order with colon/equals/dash separators', () => {
    expect(main.parseLegend('A: Caesar\nB = Vigenère\nC - ROT13'))
      .toEqual(['caesar', 'vigenere', 'rot13']);
  });

  it('parseLegend handles comma-separated legends', () => {
    expect(main.parseLegend('A: Caesar, B: ROT13')).toEqual(['caesar', 'rot13']);
  });

  it('parseLegend resolves accented and acronym labels', () => {
    expect(main.parseLegend('A: Vigenère\nB: M-209\nC: KL-7\nD: Ge’ez Monastic'))
      .toEqual(['vigenere', 'm209', 'kl7', 'geezMonastic']);
  });

  it('parseLegend ignores unknown cipher names', () => {
    expect(main.parseLegend('A: Caesar\nB: NotARealCipher')).toEqual(['caesar']);
  });

  it('parseLegend sorts entries by code so paste order does not matter', () => {
    expect(main.parseLegend('B: Vigenère\nA: Caesar')).toEqual(['caesar', 'vigenere']);
  });

  it('parseLegend accepts bare cipher names without codes (positional)', () => {
    expect(main.parseLegend('Caesar\nVigenère\nROT13')).toEqual(['caesar', 'vigenere', 'rot13']);
  });

  it('parseLegend handles whitespace-collapsed legend (mobile clipboard quirk)', () => {
    // Regression for: on a mobile device, copying our multi-line legend and
    // pasting it back collapses the newlines into spaces, leaving the entire
    // legend on one line. The parser must still recover all entries.
    expect(main.parseLegend('A: Caesar B: Vigenère C: ROT13'))
      .toEqual(['caesar', 'vigenere', 'rot13']);
  });

  it('parseLegend handles multi-word cipher names on a collapsed line', () => {
    expect(main.parseLegend('A: Confederate Vigenère B: Running Key C: Caesar'))
      .toEqual(['confederateVigenere', 'runningKey', 'caesar']);
  });

  it('parseLegend handles hyphenated names on a collapsed line', () => {
    // M-209 contains a hyphen which is also a legend separator — must not
    // confuse the parser.
    expect(main.parseLegend('A: M-209 B: KL-7 C: Four-Square'))
      .toEqual(['m209', 'kl7', 'foursquare']);
  });

  it('parseLegend handles semicolons as entry separators', () => {
    expect(main.parseLegend('A: Caesar; B: Vigenère; C: ROT13'))
      .toEqual(['caesar', 'vigenere', 'rot13']);
  });

  it('parseLegend handles legends with no whitespace after colon', () => {
    expect(main.parseLegend('A:Caesar\nB:Vigenère')).toEqual(['caesar', 'vigenere']);
  });

  it('parseLegend (code-only path) accepts comma-separated letter codes', () => {
    // The new copy format. Letters map to ciphers via the stable global
    // map; the first cipher in the registry is "caesar".
    expect(main.parseLegend('A')).toEqual(['caesar']);
    // First two registry ciphers are caesar, monoalphabetic.
    expect(main.parseLegend('A, B')).toEqual(['caesar', 'monoalphabetic']);
    expect(main.parseLegend('A,B,A')).toEqual(['caesar', 'monoalphabetic', 'caesar']);
  });

  it('parseLegend (code-only path) accepts space-separated codes', () => {
    expect(main.parseLegend('A B A B')).toEqual(['caesar', 'monoalphabetic', 'caesar', 'monoalphabetic']);
  });

  it('parseLegend (code-only path) accepts newline-separated codes', () => {
    expect(main.parseLegend('A\nB\nA')).toEqual(['caesar', 'monoalphabetic', 'caesar']);
  });

  it('parseLegend recovers from a URL-encoded paste', () => {
    // Some mobile clipboards / messaging apps URL-encode pasted text.
    // "%2C" is ",", "%20" is " ".
    expect(main.parseLegend('A%2C%20B%2C%20A')).toEqual(['caesar', 'monoalphabetic', 'caesar']);
  });

  it('parseLegend recovers from a URL-encoded legacy code+name paste', () => {
    // Reproduces the user-reported "a:%20Fialika" shape — colon becomes
    // %3A, space becomes %20. After decode and case-normalisation the
    // entry should still resolve.
    expect(main.parseLegend('A%3A%20Caesar')).toEqual(['caesar']);
  });

  it('parseLegend handles double-letter codes for ciphers past Z', () => {
    // Cipher #27 (index 26) gets code "AA" via codeForIndex.
    const codes = main.cipherNames.map((_, i) => main.codeForIndex(i));
    expect(codes[26]).toBe('AA');
    expect(main.parseLegend('A, AA')).toEqual(['caesar', main.cipherNames[26]]);
  });

  it('resolveCipherName accepts camelCase and human labels', () => {
    expect(main.resolveCipherName('caesar')).toBe('caesar');
    expect(main.resolveCipherName('Caesar')).toBe('caesar');
    expect(main.resolveCipherName('m209')).toBe('m209');
    expect(main.resolveCipherName('M-209')).toBe('m209');
    expect(main.resolveCipherName('Running Key')).toBe('runningKey');
    expect(main.resolveCipherName('Vigenère')).toBe('vigenere');
  });

  it('decodeFromLegend maps legend[i] to token[i] positionally', () => {
    const ct = `${CipherEngines.caesar.encode('HELLO', 'KEY')} | ${CipherEngines.caesar.encode('WORLD', 'KEY')}`;
    const { text, missingPositions } = main.decodeFromLegend(ct, ['caesar', 'caesar'], 'KEY');
    expect(text).toBe('HELLO WORLD');
    expect(missingPositions).toEqual([]);
  });

  it('decodeFromLegend reports missing positions when legend is short', () => {
    const ct = 'KHOOR | XYZ';
    const { missingPositions } = main.decodeFromLegend(ct, ['caesar'], '3');
    expect(missingPositions).toEqual([2]);
  });
});

describe('Global cipher↔code map', () => {
  let main;
  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    main = await import('../src/main.js');
  });

  it('codeForCipher and cipherForCode are inverses for every registered cipher', () => {
    for (const name of main.cipherNames) {
      const code = main.codeForCipher(name);
      expect(code, `codeForCipher(${name})`).toMatch(/^[A-Z]{1,3}$/);
      expect(main.cipherForCode(code)).toBe(name);
    }
  });

  it('codes are unique across all 84 ciphers', () => {
    const codes = main.cipherNames.map(main.codeForCipher);
    expect(new Set(codes).size).toBe(codes.length);
  });

  it('cipherForCode is case-insensitive', () => {
    expect(main.cipherForCode('a')).toBe('caesar');
    expect(main.cipherForCode('A')).toBe('caesar');
  });
});

describe('Tab switching does not auto-prefill decrypt fields', () => {
  let main;
  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    main = await import('../src/main.js');
  });

  it('Decrypt fields stay empty after a fresh Encrypt + tab switch', () => {
    document.getElementById('inputText').value = 'hello world';
    document.getElementById('encryptBtn').click();
    document.getElementById('decryptTab').click();
    expect(document.getElementById('cipherText').value).toBe('');
    expect(document.getElementById('legendInput').value).toBe('');
  });
});

describe('Decrypt panel (legend-driven)', () => {
  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    await import('../src/main.js');
  });

  it('full encrypt → copy → paste → decrypt round-trip recovers the message', () => {
    // Math.random=0 makes pickCiphersForWords deterministic. The first two
    // ciphers in that ordering are monoalphabetic + polybius, both lossless,
    // so a 2-word input round-trips byte-for-byte (after normalisation).
    const rand = vi.spyOn(Math, 'random').mockReturnValue(0);
    try {
      document.getElementById('inputText').value = 'ATTACK DAWN';
      document.getElementById('encryptBtn').click();

      const ciphertext = document.getElementById('outputText').dataset.plain;
      const legend = document.getElementById('cipherLegend').dataset.plain;

      // Ciphertext is just tokens — no [code] markers.
      expect(ciphertext).not.toMatch(/\[[A-Z]+\]/);
      expect(ciphertext).toContain(' | ');
      // Legend is code-only ("A, B" etc) — no cipher names in the copy.
      expect(legend).toMatch(/^[A-Z]{1,3}(,\s*[A-Z]{1,3})*$/);

      // Switch to the decrypt tab and paste both back in.
      document.getElementById('decryptTab').click();
      document.getElementById('cipherText').value = ciphertext;
      document.getElementById('legendInput').value = legend;
      document.getElementById('cipherKey').value = 'KEY';
      document.getElementById('decryptBtn').click();

      const decoded = document.getElementById('decryptedText').textContent;
      const normalized = decoded.toUpperCase().replace(/[^A-Z]/g, '');
      expect(normalized).toBe('ATTACKDAWN');
    } finally {
      rand.mockRestore();
    }
  });

  it('shows an error when no legend is provided', () => {
    document.getElementById('cipherText').value = 'KHOOR';
    document.getElementById('legendInput').value = '';
    document.getElementById('decryptBtn').click();
    const out = document.getElementById('decryptedText');
    expect(out.getAttribute('data-state')).toBe('error');
    expect(out.textContent).toMatch(/legend/i);
  });

  it('handles empty ciphertext gracefully', () => {
    document.getElementById('cipherText').value = '';
    document.getElementById('legendInput').value = 'A: Caesar';
    document.getElementById('decryptBtn').click();
    expect(document.getElementById('decryptedText').textContent).toBe('');
  });

  it('clear button resets all decrypt fields', () => {
    document.getElementById('cipherText').value = 'KHOOR';
    document.getElementById('legendInput').value = 'A: Caesar';
    document.getElementById('cipherKey').value = '3';
    document.getElementById('decryptBtn').click();

    document.getElementById('clearDecryptBtn').click();
    expect(document.getElementById('cipherText').value).toBe('');
    expect(document.getElementById('legendInput').value).toBe('');
    expect(document.getElementById('cipherKey').value).toBe('');
    expect(document.getElementById('decryptedText').textContent).toBe('');
  });

  it('regression: legend pasted as one collapsed line still decodes (mobile paste)', () => {
    // User report: on mobile the clipboard collapsed the multi-line legend
    // into one line during decoding, breaking the parser.
    const enc1 = CipherEngines.caesar.encode('HELLO', 'KEY');
    const enc2 = CipherEngines.atbash.encode('WORLD', 'KEY');
    document.getElementById('cipherText').value = `${enc1} | ${enc2}`;
    document.getElementById('legendInput').value = 'A: Caesar B: Atbash'; // one line, no newline
    document.getElementById('cipherKey').value = 'KEY';
    document.getElementById('decryptBtn').click();
    const decoded = document.getElementById('decryptedText').textContent.toUpperCase();
    expect(decoded).toContain('HELLO');
    expect(decoded).toContain('WORLD');
  });

  it('regression: short words encrypted with pad-prone ciphers round-trip cleanly (no trailing X)', () => {
    // User-reported: "I love you" encrypted with Stager on word 2 came back
    // as "I LOVEX YOU" because Stager pads to a multiple of cols=5.
    document.getElementById('cipherText').value = `${CipherEngines.commercialCode.encode('I', 'KEY')} | ${CipherEngines.stager.encode('LOVE', 'KEY')} | ${CipherEngines.nihilist.encode('YOU', 'KEY')}`;
    document.getElementById('legendInput').value = 'A: Commercial Code\nB: Stager\nC: Nihilist';
    document.getElementById('cipherKey').value = 'KEY';
    document.getElementById('decryptBtn').click();
    const decoded = document.getElementById('decryptedText').textContent.toUpperCase();
    expect(decoded).toContain('I');
    expect(decoded).toContain('LOVE');
    expect(decoded).not.toContain('LOVEX');
    expect(decoded).toContain('YOU');
  });

  it('copes with ciphertext that contains internal whitespace (e.g. Polybius)', () => {
    // Polybius outputs space-separated digit pairs. The | delimiter must
    // preserve those internal spaces.
    const enc1 = CipherEngines.polybius.encode('HELLO', 'KEY');
    const enc2 = CipherEngines.caesar.encode('WORLD', 'KEY');
    expect(enc1).toMatch(/\d+ \d+/); // sanity: contains spaces
    document.getElementById('cipherText').value = `${enc1} | ${enc2}`;
    document.getElementById('legendInput').value = 'A: Polybius\nB: Caesar';
    document.getElementById('cipherKey').value = 'KEY';
    document.getElementById('decryptBtn').click();
    const decoded = document.getElementById('decryptedText').textContent;
    expect(decoded.toUpperCase()).toContain('HELLO');
    expect(decoded.toUpperCase()).toContain('WORLD');
  });
});

describe('Copy to clipboard', () => {
  beforeEach(async () => {
    setupDom();
    vi.resetModules();
    await import('../src/main.js');
  });

  it('copy ciphertext button writes the | -delimited tokens to the clipboard (no codes)', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', { value: { writeText }, configurable: true });

    document.getElementById('inputText').value = 'hello world';
    document.getElementById('encryptBtn').click();
    document.getElementById('copyEncryptBtn').click();
    await new Promise(r => setTimeout(r, 0));

    expect(writeText).toHaveBeenCalledTimes(1);
    const arg = writeText.mock.calls[0][0];
    expect(arg).not.toMatch(/\[[A-Z]+\]/);
    expect(arg).toContain(' | ');
    expect(arg.split(' | ').length).toBe(2);
  });

  it('copy legend button writes codes only (no cipher names) so paste survives clipboard mangling', async () => {
    const writeText = vi.fn().mockResolvedValue(undefined);
    Object.defineProperty(navigator, 'clipboard', { value: { writeText }, configurable: true });

    document.getElementById('inputText').value = 'hi there';
    document.getElementById('encryptBtn').click();
    document.getElementById('copyLegendBtn').click();
    await new Promise(r => setTimeout(r, 0));

    expect(writeText).toHaveBeenCalledTimes(1);
    const arg = writeText.mock.calls[0][0];
    // Codes only: comma-separated 1-3 letter tokens.
    expect(arg).toMatch(/^[A-Z]{1,3}(,\s*[A-Z]{1,3})*$/);
    // Critically, no cipher names — no colons, no accents, no spaces inside
    // a token.
    expect(arg).not.toMatch(/[a-z]/);
    expect(arg).not.toContain(':');
  });
});
