# ⚠️ WARNING: PRIVATE KEYS ARE STORED IN THIS REPO

The `keys/` directory contains real private keys and certificates:

- `keys/mykey.key` — Apple Distribution certificate private key
- `keys/certificate.p12` — Packaged cert + private key
- `keys/ASC_PRIVATE_KEY.txt` — App Store Connect API private key (base64)

## THIS IS TEMPORARY

These keys are here because the codespace kept getting wiped and there
was no other backup. This is NOT a secure long-term solution.

## TODO: MOVE THESE KEYS OUT OF THE REPO

Better options (in order of preference):
1. **1Password / Bitwarden / any password manager** — store each file as a
   secure note or attachment. Free and easy.
2. **Apple Keychain on a Mac** — the proper place for these if you ever get
   a Mac.
3. **GitHub Codespaces Secrets** — store as environment variables so they
   are available in the codespace but not in the repo.

Once the keys are safely stored elsewhere, delete the `keys/` directory,
restore the `.gitignore` entries, and commit.
