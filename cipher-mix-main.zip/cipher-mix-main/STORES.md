# Releasing Cipher Mix to the App Store and Play Store

This file documents the GUI/credential steps you have to do yourself —
everything that can't be done from a Linux codespace.

The repo is already wired for native builds:

```bash
npm run build:native        # vite build with relative asset paths (for Capacitor)
npm run cap:sync            # build:native + cap sync (copies dist/ into ios/ and android/)
npm run cap:icons           # regenerates icons + splash from resources/
```

Bundle ID for both stores: **`com.systemslibrarian.ciphermix`**
(this is permanent — once a store has accepted a build with this ID,
you can't change it).

---

## Apple App Store (macOS + Xcode required)

1. **One-time setup**
   - Sign in to https://developer.apple.com with your Apple Developer account.
   - In **Certificates, Identifiers & Profiles** → **Identifiers** → register
     `com.systemslibrarian.ciphermix`.
   - In **App Store Connect** → **My Apps** → **+** → **New App**:
     - Bundle ID: `com.systemslibrarian.ciphermix`
     - Name: **Cipher Mix**
     - Primary language: English
     - SKU: anything unique, e.g. `cipher-mix-001`

2. **Each release**
   ```bash
   npm run cap:sync
   npm run cap:open:ios
   ```
   In Xcode:
   - Select the **App** target → **Signing & Capabilities** → check
     *Automatically manage signing* → pick your Team.
   - Bump the **Version** (e.g. 1.0.0) and **Build** (e.g. 1) numbers.
   - Choose **Any iOS Device (arm64)** as the run target.
   - **Product → Archive** → wait for the archive to finish.
   - In the Organizer that opens, click **Distribute App** → **App Store Connect**
     → **Upload** → follow prompts. The first upload takes 30–60 minutes to
     process server-side.

3. **Store listing** (in App Store Connect, web UI)
   - **App Information**: category (suggest *Reference* or *Utilities*),
     content rights, age rating.
   - **Pricing**: Free.
   - **App Privacy**: data collection answers — Cipher Mix collects nothing,
     so every section is "We do not collect data."
   - **Privacy Policy URL**: Apple requires one even if you collect nothing.
     A simple GitHub Pages page is enough — see `PRIVACY.md` template below.
   - **Screenshots**: at minimum 6.7" iPhone and 12.9" iPad. Take them from
     the simulator (`File → New Screenshot` in Xcode after running on a
     simulator at the right size).
   - **Description**, **keywords**, **support URL** (your GitHub repo works).
   - Submit for Review. Apple typically responds in 1–3 days.

---

## Google Play Store

1. **One-time setup**
   - Sign in to https://play.google.com/console with your Play Console account.
   - **Create app** → name *Cipher Mix*, free, English.
   - In **Setup → App signing**, opt in to **Play App Signing** (Google manages
     the upload key).

2. **Each release**
   ```bash
   npm run cap:sync
   npm run cap:open:android
   ```
   In Android Studio:
   - First run only: **Build → Generate Signed Bundle / APK** → **Android App
     Bundle** → **Create new** keystore (save the `.jks` somewhere safe —
     you'll reuse it for every release).
   - **Build → Generate Signed Bundle / APK** → select the AAB → **release**
     build variant → uses your existing keystore → produces `app-release.aab`
     in `android/app/release/`.
   - Bump `versionCode` (integer, must increase every release) and
     `versionName` (e.g. 1.0.0) in `android/app/build.gradle`.

3. **Store listing** (in Play Console)
   - **Main store listing**: short + full description, screenshots
     (phone + tablet), feature graphic (1024 × 500), app icon (512 × 512).
   - **Content rating**: fill in the questionnaire — Cipher Mix is "Everyone".
   - **Target audience**: choose age group; keep it 13+ to avoid COPPA
     extras.
   - **Data safety**: declare *no data collected*.
   - **Privacy Policy URL**: required — same GitHub Pages page as iOS.
   - Upload the AAB under **Production → Create release** → review → roll out.
   - Google review usually takes < 24 h on the first submission.

---

## Privacy policy boilerplate (`PRIVACY.md`)

Drop something like this on your site at e.g.
`https://systemslibrarian.github.io/cipher-mix/privacy.html`:

> **Cipher Mix Privacy Policy**
>
> Cipher Mix is a fully client-side app. It does not collect, transmit, or
> store any personal data. Messages you encrypt or decrypt are processed
> locally on your device and never leave it. The app does not use analytics,
> advertising identifiers, or third-party SDKs.
>
> Contact: [your email]

---

## Updating later

A normal release is now:

```bash
git pull
npm install
npm run cap:sync
# bump version in Xcode (iOS) and android/app/build.gradle (Android)
# Archive + upload from Xcode; Generate Signed Bundle + upload to Play Console
```

That's it.
