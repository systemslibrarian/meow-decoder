# Cipher Mix

Encrypt each word of a message with a different historical cipher — or decrypt a single message with any one of **84** built-in engines (Caesar, Vigenère, Enigma, Lorenz, Playfair, ADFGVX, Bifid, Trifid, Bacon, Pigpen, Tap Code, M-209, KL-7, Purple, JN-25, Solitaire, Chaocipher, Voynich, Kryptos, and many more).

Built with vanilla JS + Vite. No frameworks, no telemetry, ~67 KB JS gzipped.

## Quick start

```bash
npm install
npm run dev      # http://localhost:5173/cipher-mix/
npm test         # run vitest
npm run build    # output dist/
npm run preview  # serve dist/
```

## Project layout

```
src/
  main.js                   # app entry: render + wire encrypt/decrypt UI
  style.css                 # accessible, responsive styles
  ciphers/all-engines.js    # 84-cipher registry (encode/decode)
  assets/hero.png
public/
  favicon.svg, icons.svg, .nojekyll
tests/
  cipher-engines.test.js    # registry, round-trip, count
  app-integration.test.js   # rendering, tabs, decrypt, copy, XSS
.github/workflows/gh-pages.yml
vite.config.js              # base: /cipher-mix/
index.html
```

## Accessibility

- Skip-link, semantic landmarks (`<main>`, `<header>`, `<footer>`)
- Every form control has a real `<label>`; inputs `aria-describedby` their hints
- ARIA tabs pattern with arrow-key / Home / End navigation and roving `tabindex`
- `aria-live="polite"` regions for output + a screen-reader status channel
- 44 px minimum touch targets, 3 px focus-visible outline with dedicated focus colour
- Honours `prefers-color-scheme`, `prefers-reduced-motion`, and `forced-colors`
- HTML-escaped output (XSS-safe; covered by a unit test)

## Mobile

- `viewport-fit=cover` with safe-area insets
- Fluid `clamp()` typography
- Single-column layout under 480 px; full-width buttons stack
- 16 px input font size to suppress iOS auto-zoom

## Deploy

### Web (GitHub Pages)

Pushes to `main` trigger `.github/workflows/gh-pages.yml`, which runs
`npm test`, then `npm run build`, then deploys `dist/` via
`actions/deploy-pages`. Vite uses `base: '/cipher-mix/'` for this build.

Live: https://systemslibrarian.github.io/cipher-mix/

### Native apps (iOS / Android via Capacitor)

The repo is wired with Capacitor so the same codebase ships as a native
iOS and Android app. Bundle ID: `com.systemslibrarian.ciphermix`. Icon
and splash are already generated from [`resources/icon.svg`](resources/icon.svg).

**Android — build a debug APK right here in this codespace, no Android Studio:**

```bash
npm run android:setup      # one-time: installs Android cmdline-tools + SDK (~1 GB)
npm run android:debug      # produces android/app/build/outputs/apk/debug/app-debug.apk
npm run android:release    # signed AAB for Play Store (needs keystore env vars)
```

For the signed release AAB:

```bash
keytool -genkeypair -v -keystore ~/cipher-mix-release.jks \
    -alias cipher-mix -keyalg RSA -keysize 2048 -validity 10000   # one-time, back this up
export CM_KEYSTORE=~/cipher-mix-release.jks
export CM_KEYSTORE_PASSWORD='…'
export CM_KEY_ALIAS=cipher-mix
export CM_KEY_PASSWORD='…'
npm run android:release
```

**iOS — the [release.yml](.github/workflows/release.yml) workflow ships to TestFlight from a `macos-latest` GitHub-hosted runner:**

```bash
git tag v0.1.0 && git push origin v0.1.0
```

…or trigger it manually from the **Actions** tab. You'll need to set up
seven repository secrets first — see [`docs/RELEASE-CI.md`](docs/RELEASE-CI.md)
for the full walkthrough.

If you'd rather build locally on a Mac with Xcode:

```bash
npm run cap:open:ios
```

Store-listing details (screenshots, privacy policy, content ratings,
review process) are in [`STORES.md`](STORES.md).

### Steady-state release loop

```bash
git pull && npm install
npm run cap:sync                  # web changes flow into both native projects

# Android (locally, in this codespace)
# - bump versionCode in android/app/build.gradle
npm run android:release           # produces app-release.aab; upload to Play Console

# iOS — push a new version tag and let GitHub Actions ship to TestFlight
git tag v1.0.1 && git push origin v1.0.1
```

### Quick reference

| Want to                        | Run                        |
|--------------------------------|----------------------------|
| Local web dev                  | `npm run dev`              |
| Run tests                      | `npm test`                 |
| Build for GitHub Pages         | `npm run build`            |
| Build for Capacitor            | `npm run build:native`     |
| Sync web build into native     | `npm run cap:sync`         |
| Regenerate icons + splash      | `npm run cap:icons`        |
| Install Android SDK (one time) | `npm run android:setup`    |
| Build a debug APK              | `npm run android:debug`    |
| Build a signed release AAB     | `npm run android:release`  |
| Open Xcode (Mac only)          | `npm run cap:open:ios`     |
| Ship iOS to TestFlight         | `git tag vX.Y.Z && git push --tags` |

## Tests

58 tests across two files (`tests/cipher-engines.test.js`,
`tests/app-integration.test.js`). They cover:

- The registry has exactly 84 ciphers, each with `encode` and `decode`.
- 77 ciphers strictly round-trip — `decode(encode(x)) === x`.
- All 84 ciphers are reachable through the UI (driven via a deterministic
  `Math.random` stub).
- ARIA tabs pattern: selection state, arrow-key/Home/End navigation,
  roving `tabindex`.
- Legend parser handles every paste shape: code-only `A, B, C`,
  whitespace-collapsed `A B C`, URL-encoded `A%2C%20B`, mixed cases,
  legacy `A: Caesar` format, multi-word and hyphenated cipher names.
- XSS escape, copy-to-clipboard payload, end-to-end encrypt → decrypt
  round-trip.
- Pad-prone ciphers (Stager, Scytale, Four-/Two-Square, Slidex, Cardano
  Grille) strip filler `X` on decode for short inputs.
