# Keys & Certificates

| File | What it is | Used in |
|---|---|---|
| `mykey.key` | Private key for the Apple Distribution certificate | `BUILD_CERTIFICATE_BASE64` secret |
| `distribution.cer` | Apple Distribution certificate (public) | Combined with mykey.key to make .p12 |
| `distribution.pem` | Same cert in PEM format | Intermediate step |
| `certificate.p12` | Packaged cert + private key (PKCS12) | `BUILD_CERTIFICATE_BASE64` secret |
| `ASC_PRIVATE_KEY.txt` | base64 of AuthKey_N7SFL234VZ.p8 | `ASC_PRIVATE_KEY` secret |

## If you need to regenerate secrets from these files

```bash
# Rebuild BUILD_CERTIFICATE_BASE64
base64 -i keys/certificate.p12 | tr -d '\n'

# P12 password is stored in the P12_PASSWORD GitHub secret

# ASC_PRIVATE_KEY is already base64 — just copy keys/ASC_PRIVATE_KEY.txt
```

## ASC API Key details
- Key ID: `N7SFL234VZ`
- Issuer ID: stored in `ASC_ISSUER_ID` GitHub secret
