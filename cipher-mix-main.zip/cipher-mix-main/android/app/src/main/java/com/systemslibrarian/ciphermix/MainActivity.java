package com.systemslibrarian.ciphermix;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
